﻿/*
 * Si quieres, puedes ocupar este MAIN para debuggear tu código.
 */

Console.WriteLine("Hello world!");