namespace VehicleRoutingValidator.VehicleRouting;

public class Precedence
{
    public int PickUpLocation { get; set; }
    public int DeliveryLocation { get; set; }
}